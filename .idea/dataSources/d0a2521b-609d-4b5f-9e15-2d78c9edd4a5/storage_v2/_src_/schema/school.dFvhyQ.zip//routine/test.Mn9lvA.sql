create procedure test(IN num INT(10))
  begin
select num;
end;

