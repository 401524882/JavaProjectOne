create procedure getName(IN inName VARCHAR(50), OUT stuName VARCHAR(50))
  begin
select name into stuName from student where name=inName;
end;

